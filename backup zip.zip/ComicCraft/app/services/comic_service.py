from __future__ import annotations

from uuid import uuid4

from app.config import settings
from app.schemas import ComicRequest, ComicStory
from app.services.exporters import create_pdf
from app.services.gemini import generate_outline, generate_story
from app.services.image_generator import generate_panel_image
from app.services.layout_builder import build_prompts


def _mock_story(request: ComicRequest) -> ComicStory:
    panels = []

    for number in range(1, settings.comic_panels + 1):
        panels.append(
            {
                "panel_number": number,
                "title": f"Scene {number}",
                "scene_description": (
                    f"{request.character_name} continues the adventure "
                    f"in {request.setting}."
                ),
                "caption": f"Panel {number}",
                "narration": (
                    f"{request.character_name} moves the story forward."
                ),
                "dialogue": [
                    "Let's keep going!",
                ],
                "image_prompt": (
                    f"{request.character_name} in {request.setting}, "
                    f"{request.art_style}, {request.tone}, "
                    f"comic illustration"
                ),
            }
        )

    return ComicStory(
        title=f"{request.character_name}'s Comic Adventure",
        panels=panels,
    )


def generate_comic(
    request: ComicRequest,
) -> tuple[ComicStory, str]:

    if settings.mock_ai:
        story = _mock_story(request)
    else:
        outline = generate_outline(request)
        story = generate_story(request, outline)

    prompts = build_prompts(request, story)

    job_id = uuid4().hex[:12]

    image_paths = []

    for index, prompt in enumerate(prompts, start=1):
        image_path = generate_panel_image(
            prompt=prompt,
            panel_number=index,
            job_id=job_id,
        )

        image_paths.append(image_path)

    pdf_path = settings.exports_dir / f"{job_id}_comic.pdf"

    create_pdf(
        story,
        image_paths,
        pdf_path,
    )

    return story, job_id