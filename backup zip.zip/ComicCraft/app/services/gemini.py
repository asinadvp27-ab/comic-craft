from __future__ import annotations

import json
from typing import Type, TypeVar

from google import genai
from google.genai import types
from pydantic import BaseModel

from app.config import settings
from app.schemas import ComicOutline, ComicRequest, ComicStory


T = TypeVar("T", bound=BaseModel)


def _client() -> genai.Client:
    if not settings.gemini_api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Add it to your .env file "
            "or enable COMICCRAFT_MOCK_AI=true."
        )

    return genai.Client(
        api_key=settings.gemini_api_key
    )


def _generate_structured(
    prompt: str,
    response_schema: Type[T],
) -> T:

    client = _client()

    response = client.models.generate_content(
        model=settings.gemini_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.8,
            response_mime_type="application/json",
            response_schema=response_schema,
        ),
    )

    if not response.text:
        raise RuntimeError(
            "Gemini returned an empty response."
        )

    try:
        data = json.loads(response.text)

    except json.JSONDecodeError as exc:
        raise RuntimeError(
            "Gemini returned invalid JSON."
        ) from exc

    return response_schema.model_validate(data)


def generate_outline(
    request: ComicRequest,
) -> ComicOutline:

    panel_count = settings.comic_panels

    prompt = f"""
You are a professional comic-book story planner.

Create a complete {panel_count}-panel comic outline.

User story:
{request.story_prompt}

Main character:
{request.character_name}

Setting:
{request.setting}

Tone:
{request.tone}

Art style:
{request.art_style}

Rules:
- Return exactly {panel_count} panels.
- Keep the main character visually consistent.
- Make the story have a clear beginning, development, and ending.
- Each panel needs a useful scene description.
- Each image_prompt must be detailed enough for an image-generation model.
- Do not include markdown.
- Do not include text outside the requested JSON structure.
"""

    outline = _generate_structured(
        prompt,
        ComicOutline,
    )

    outline.panels = outline.panels[:panel_count]

    if len(outline.panels) != panel_count:
        raise RuntimeError(
            f"Gemini returned {len(outline.panels)} panels "
            f"instead of {panel_count}."
        )

    for index, panel in enumerate(
        outline.panels,
        start=1,
    ):
        panel.panel_number = index

    return outline


def generate_story(
    request: ComicRequest,
    outline: ComicOutline,
) -> ComicStory:

    outline_json = outline.model_dump_json(
        indent=2
    )

    prompt = f"""
You are a professional comic-book writer.

Write the final dialogue and narration for this comic.

Character:
{request.character_name}

Setting:
{request.setting}

Tone:
{request.tone}

Art style:
{request.art_style}

Original story prompt:
{request.story_prompt}

Approved outline:
{outline_json}

Rules:
- Preserve the exact panel count.
- Keep the character and plot consistent.
- Dialogue should sound natural and concise.
- Narration should be short enough for a comic panel.
- Do not make dialogue overly long.
- Do not use markdown.
- Return only the requested JSON structure.
"""

    story = _generate_structured(
        prompt,
        ComicStory,
    )

    story.panels = story.panels[:len(outline.panels)]

    if len(story.panels) != len(outline.panels):
        raise RuntimeError(
            "Gemini changed the number of panels."
        )

    for index, panel in enumerate(
        story.panels,
        start=1,
    ):
        panel.panel_number = index

    return story