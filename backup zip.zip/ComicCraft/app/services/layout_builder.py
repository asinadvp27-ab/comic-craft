from __future__ import annotations

from app.schemas import ComicRequest, ComicStory


def build_image_prompt(
    request: ComicRequest,
    scene_description: str,
    image_prompt: str,
) -> str:

    return f"""
Comic-book illustration.

Main character: {request.character_name}
Setting: {request.setting}
Tone: {request.tone}
Art style: {request.art_style}

Scene:
{scene_description}

Visual prompt:
{image_prompt}

Requirements:
- consistent character appearance
- expressive facial/body language
- clear foreground, middle ground and background
- cinematic composition
- polished comic-book illustration
- no watermark
- no UI
- no random letters or logos
""".strip()


def build_prompts(
    request: ComicRequest,
    story: ComicStory,
) -> list[str]:

    return [
        build_image_prompt(
            request,
            panel.scene_description,
            panel.image_prompt,
        )
        for panel in story.panels
    ]