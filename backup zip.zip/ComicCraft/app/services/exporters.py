from __future__ import annotations

from pathlib import Path

from PIL import Image
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas

from app.schemas import ComicStory


def _wrap_text(
    text: str,
    max_chars: int = 95,
) -> list[str]:

    words = text.split()
    lines: list[str] = []
    current = ""

    for word in words:
        candidate = f"{current} {word}".strip()

        if len(candidate) <= max_chars:
            current = candidate
        else:
            if current:
                lines.append(current)

            current = word

    if current:
        lines.append(current)

    return lines


def create_pdf(
    story: ComicStory,
    image_paths: list[Path],
    output_path: Path,
) -> Path:

    width, height = A4

    pdf = canvas.Canvas(
        str(output_path),
        pagesize=A4,
    )

    for index, (panel, image_path) in enumerate(
        zip(story.panels, image_paths),
        start=1,
    ):

        pdf.setFont(
            "Helvetica-Bold",
            18,
        )

        pdf.drawString(
            40,
            height - 45,
            f"{story.title} — Panel {index}",
        )

        image = Image.open(image_path)

        image.thumbnail(
            (
                width - 80,
                420,
            )
        )

        image_reader = ImageReader(image)

        x = (width - image.width) / 2
        y = height - 500

        pdf.drawImage(
            image_reader,
            x,
            y,
            width=image.width,
            height=image.height,
            preserveAspectRatio=True,
            mask="auto",
        )

        text_y = y - 30

        if panel.caption:
            pdf.setFont(
                "Helvetica-Bold",
                11,
            )

            for line in _wrap_text(
                panel.caption,
                100,
            ):
                pdf.drawString(
                    40,
                    text_y,
                    line,
                )
                text_y -= 15

        if panel.narration:
            pdf.setFont(
                "Helvetica",
                10,
            )

            for line in _wrap_text(
                panel.narration,
                100,
            ):
                pdf.drawString(
                    40,
                    text_y,
                    line,
                )
                text_y -= 14

        if panel.dialogue:
            pdf.setFont(
                "Helvetica-Oblique",
                10,
            )

            for dialogue in panel.dialogue:

                for line in _wrap_text(
                    f"“{dialogue}”",
                    100,
                ):
                    pdf.drawString(
                        40,
                        text_y,
                        line,
                    )
                    text_y -= 14

        pdf.showPage()

    pdf.save()

    return output_path