from __future__ import annotations

import hashlib
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from app.config import settings


def _safe_filename(value: str) -> str:
    cleaned = "".join(
        char.lower() if char.isalnum() else "_"
        for char in value
    )

    return cleaned.strip("_")[:80] or "panel"


def _font(size: int):
    candidates = [
        "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]

    for candidate in candidates:
        path = Path(candidate)

        if path.exists():
            try:
                return ImageFont.truetype(
                    str(path),
                    size,
                )
            except OSError:
                pass

    return ImageFont.load_default()


def _mock_image(
    prompt: str,
    output_path: Path,
    panel_number: int,
) -> Path:

    digest = hashlib.md5(
        prompt.encode("utf-8")
    ).hexdigest()

    seed = int(
        digest[:8],
        16,
    )

    width = 1024
    height = 768

    image = Image.new(
        "RGB",
        (width, height),
        (245, 240, 225),
    )

    draw = ImageDraw.Draw(image)

    x1 = 100 + seed % 250
    y1 = 100 + (seed // 7) % 180

    x2 = 650 + (seed // 11) % 180
    y2 = 350 + (seed // 17) % 180

    draw.ellipse(
        (
            x1,
            y1,
            x1 + 190,
            y1 + 190,
        ),
        outline=(30, 30, 30),
        width=8,
    )

    draw.rectangle(
        (
            x2,
            y2,
            x2 + 150,
            y2 + 130,
        ),
        outline=(30, 30, 30),
        width=8,
    )

    title_font = _font(44)
    body_font = _font(26)

    draw.text(
        (50, 35),
        f"ComicCraft — Panel {panel_number}",
        font=title_font,
        fill=(20, 20, 20),
    )

    lines = [
        "MOCK IMAGE MODE",
        "Connect Hugging Face later",
        "to generate real illustrations.",
    ]

    y = height - 150

    for line in lines:
        draw.text(
            (50, y),
            line,
            font=body_font,
            fill=(40, 40, 40),
        )

        y += 35

    image.save(output_path)

    return output_path


def _hf_image(
    prompt: str,
    output_path: Path,
) -> Path:

    if not settings.hf_token:
        raise RuntimeError(
            "HF_TOKEN is missing. Add it to .env "
            "or use IMAGE_BACKEND=mock."
        )

    from huggingface_hub import InferenceClient

    client = InferenceClient(
        provider=settings.image_provider,
        api_key=settings.hf_token,
    )

    image = client.text_to_image(
        prompt=prompt,
        model=settings.image_model,
    )

    image.save(output_path)

    return output_path


def _local_image(
    prompt: str,
    output_path: Path,
) -> Path:

    try:
        import torch
        from diffusers import StableDiffusionPipeline

    except ImportError as exc:
        raise RuntimeError(
            "Local image generation requires torch and diffusers. "
            "Install the optional local dependencies."
        ) from exc

    device = settings.local_image_device

    if device == "auto":
        device = (
            "cuda"
            if torch.cuda.is_available()
            else "cpu"
        )

    pipe = StableDiffusionPipeline.from_pretrained(
        settings.image_model
    )

    if device == "cuda":
        pipe = pipe.to("cuda")
    else:
        pipe = pipe.to("cpu")

    image = pipe(
        prompt,
        num_inference_steps=25,
    ).images[0]

    image.save(output_path)

    return output_path


def generate_panel_image(
    prompt: str,
    panel_number: int,
    job_id: str,
) -> Path:

    filename = (
        f"{job_id}_panel_{panel_number:02d}.png"
    )

    output_path = (
        settings.panels_dir / filename
    )

    backend = settings.image_backend.lower().strip()

    if backend == "mock":
        return _mock_image(
            prompt,
            output_path,
            panel_number,
        )

    if backend == "hf":
        return _hf_image(
            prompt,
            output_path,
        )

    if backend == "local":
        return _local_image(
            prompt,
            output_path,
        )

    raise RuntimeError(
        f"Unknown IMAGE_BACKEND='{settings.image_backend}'. "
        "Use mock, hf, or local."
    )