from typing import List

from pydantic import BaseModel, Field, field_validator


class PanelOutline(BaseModel):
    panel_number: int = Field(
        ge=1,
        le=20,
    )

    title: str = Field(
        min_length=1,
        max_length=120,
    )

    scene_description: str = Field(
        min_length=1,
        max_length=1200,
    )

    image_prompt: str = Field(
        min_length=1,
        max_length=1600,
    )


class ComicOutline(BaseModel):
    title: str = Field(
        min_length=1,
        max_length=160,
    )

    panels: List[PanelOutline] = Field(
        min_length=1,
        max_length=20,
    )


class PanelStory(BaseModel):
    panel_number: int = Field(
        ge=1,
    )

    title: str = Field(
        min_length=1,
        max_length=120,
    )

    scene_description: str = Field(
        min_length=1,
        max_length=1600,
    )

    caption: str = Field(
        default="",
        max_length=800,
    )

    narration: str = Field(
        default="",
        max_length=1400,
    )

    dialogue: List[str] = Field(
        default_factory=list,
        max_length=8,
    )

    image_prompt: str = Field(
        min_length=1,
        max_length=1800,
    )


class ComicStory(BaseModel):
    title: str = Field(
        min_length=1,
        max_length=160,
    )

    panels: List[PanelStory] = Field(
        min_length=1,
        max_length=20,
    )


class ComicRequest(BaseModel):
    story_prompt: str = Field(
        min_length=3,
        max_length=3000,
    )

    character_name: str = Field(
        min_length=1,
        max_length=80,
    )

    setting: str = Field(
        min_length=1,
        max_length=120,
    )

    tone: str = Field(
        min_length=1,
        max_length=80,
    )

    art_style: str = Field(
        min_length=1,
        max_length=120,
    )

    @field_validator(
        "story_prompt",
        "character_name",
        "setting",
        "tone",
        "art_style",
    )
    @classmethod
    def strip_values(cls, value: str) -> str:
        value = value.strip()

        if not value:
            raise ValueError("Value cannot be empty.")

        return value


class ComicResponse(BaseModel):
    title: str

    panels: List[PanelStory]

    pdf_url: str