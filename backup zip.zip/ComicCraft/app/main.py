from pathlib import Path

from fastapi import FastAPI

from fastapi.staticfiles import (
    StaticFiles,
)

from fastapi.templating import (
    Jinja2Templates,
)

from app.config import settings
from app.routes import router


BASE_DIR = (
    Path(__file__)
    .resolve()
    .parent
    .parent
)


app = FastAPI(
    title=settings.app_name,

    version="1.0.0",

    description=(
        "AI-powered personalized "
        "comic story and illustration "
        "generator."
    ),
)


# ============================================================
# STATIC FILES
# ============================================================

app.mount(
    "/static",
    StaticFiles(
        directory=str(
            BASE_DIR / "static"
        )
    ),
    name="static",
)


# ============================================================
# GENERATED PANEL IMAGES
# ============================================================

app.mount(
    "/panels",
    StaticFiles(
        directory=str(
            settings.panels_dir
        )
    ),
    name="panels",
)


# ============================================================
# GENERATED PDF FILES
# ============================================================

app.mount(
    "/exports",
    StaticFiles(
        directory=str(
            settings.exports_dir
        )
    ),
    name="exports",
)


# ============================================================
# JINJA2 TEMPLATES
# ============================================================

templates = Jinja2Templates(
    directory=str(
        BASE_DIR / "templates"
    )
)


app.state.templates = templates


# ============================================================
# ROUTES
# ============================================================

app.include_router(router)


# ============================================================
# HEALTH CHECK
# ============================================================

@app.get("/health")
def health():

    return {
        "status": "ok",

        "app": settings.app_name,

        "environment": settings.environment,

        "mock_ai": settings.mock_ai,

        "image_backend": settings.image_backend,
    }