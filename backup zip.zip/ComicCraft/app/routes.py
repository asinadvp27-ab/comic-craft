from __future__ import annotations

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import ValidationError

from app.config import settings
from app.schemas import ComicRequest, ComicResponse
from app.services.comic_service import generate_comic


router = APIRouter()


def _pdf_url(job_id: str) -> str:
    return f"/exports/{job_id}_comic.pdf"


@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return request.app.state.templates.TemplateResponse(
        "index.html",
        {"request": request},
    )


@router.post("/generate", response_class=HTMLResponse)
async def generate_from_form(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        comic_request = ComicRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )

        story, job_id = generate_comic(comic_request)

    except (ValidationError, ValueError) as exc:
        raise HTTPException(
            status_code=422,
            detail=str(exc),
        ) from exc

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=str(exc),
        ) from exc

    panel_data = []

    for panel in story.panels:
        panel_data.append(
            {
                "panel_number": panel.panel_number,
                "title": panel.title,
                "scene_description": panel.scene_description,
                "caption": panel.caption,
                "narration": panel.narration,
                "dialogue": panel.dialogue,
                "image_url": (
                    f"/panels/"
                    f"{job_id}_panel_{panel.panel_number:02d}.png"
                ),
            }
        )

    return request.app.state.templates.TemplateResponse(
        "comic_preview.html",
        {
            "request": request,
            "title": story.title,
            "panels": panel_data,
            "pdf_url": _pdf_url(job_id),
        },
    )


@router.post("/generate-comic/json", response_model=ComicResponse)
async def generate_json(comic_request: ComicRequest):
    try:
        story, job_id = generate_comic(comic_request)

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=str(exc),
        ) from exc

    return ComicResponse(
        title=story.title,
        panels=story.panels,
        pdf_url=_pdf_url(job_id),
    )


@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request):
    return request.app.state.templates.TemplateResponse(
        "export_success.html",
        {"request": request},
    )


@router.get("/health")
async def health():
    return {
        "status": "ok",
        "app": settings.app_name,
        "mock_ai": settings.mock_ai,
        "image_backend": settings.image_backend,
    }