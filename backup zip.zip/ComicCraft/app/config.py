from pathlib import Path
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    app_name: str = "ComicCraft"
    environment: str = "development"
    host: str = "127.0.0.1"
    port: int = 8000

    gemini_api_key: str = ""
    gemini_model: str = "gemini-2.5-flash"

    hf_token: str = ""
    image_backend: str = "mock"
    image_model: str = "stabilityai/stable-diffusion-3.5-large"
    image_provider: str = "auto"
    local_image_device: str = "auto"

    comic_panels: int = 5
    max_prompt_length: int = 3000

    output_dir: Path = BASE_DIR / "outputs"
    panels_dir: Path = BASE_DIR / "outputs" / "panels"
    exports_dir: Path = BASE_DIR / "outputs" / "exports"

    mock_ai: bool = Field(
        default=True,
        validation_alias="COMICCRAFT_MOCK_AI"
    )

    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    def ensure_directories(self) -> None:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.panels_dir.mkdir(parents=True, exist_ok=True)
        self.exports_dir.mkdir(parents=True, exist_ok=True)


settings = Settings()
settings.ensure_directories()