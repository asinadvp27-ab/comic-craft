# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI + Jinja2 web application that generates a personalized five-panel comic from a user prompt.

## Architecture

- **Frontend:** HTML, CSS, Jinja2
- **Backend:** FastAPI
- **Story outline:** Google Gemini structured JSON
- **Narration/dialogue:** Google Gemini structured JSON
- **Illustrations:** Hugging Face Inference Providers with a Stable Diffusion model, or optional local Diffusers
- **Layout:** Python service layer
- **Export:** ReportLab PDF
- **API:** Browser form + JSON endpoint + image test endpoint
- **Testing:** pytest with a fully offline mock mode

The implementation follows the supplied project document's flow: input → outline → story/dialogue → image generation → layout → PDF → preview/export.

## 1. VS Code setup — Windows

Open the `ComicCraft` folder in VS Code.

### Create a virtual environment

```powershell
py -3.12 -m venv .venv
.venv\Scripts\activate
```

### Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### Configure API keys

Copy `.env.example` to `.env`.

```powershell
copy .env.example .env
```

Set:

```text
GEMINI_API_KEY=your_key
HF_TOKEN=your_huggingface_token
```

For a no-key local UI/test run, use:

```text
COMICCRAFT_MOCK_AI=true
IMAGE_BACKEND=mock
```

## 2. Run the application

```powershell
python run.py
```

Open:

- http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs
- Health: http://127.0.0.1:8000/health

## 3. Real AI configuration

### Gemini

Create a Gemini API key in Google AI Studio and put it in `.env`.

The application uses the official `google-genai` Python SDK and structured JSON output with Pydantic schemas.

Recommended current defaults can be changed without editing Python:

```text
GEMINI_OUTLINE_MODEL=gemini-3.8-flash
GEMINI_STORY_MODEL=gemini-3.8-flash
```

If your account does not have access to a selected model, choose an available model in `.env`.

### Hugging Face

Create a Hugging Face user access token with inference permissions and put it in:

```text
HF_TOKEN=hf_...
```

Default image backend:

```text
IMAGE_BACKEND=hf
IMAGE_MODEL=stabilityai/stable-diffusion-3.5-large
IMAGE_PROVIDER=auto
```

The image service uses `huggingface_hub.InferenceClient`.

## 4. Optional local Stable Diffusion

The supplied document also references Hugging Face Diffusers and `runwayml/stable-diffusion-v1-5`.

Install the optional packages:

```powershell
pip install diffusers transformers torch
```

Then set:

```text
IMAGE_BACKEND=local
IMAGE_MODEL=stabilityai/stable-diffusion-3.5-large
LOCAL_IMAGE_DEVICE=auto
```

A CUDA-capable GPU is strongly recommended for local image generation. The first model load can be large and slow.

## 5. API testing

### Health

```powershell
curl http://127.0.0.1:8000/health
```

### Generate comic through JSON API

```powershell
curl -X POST http://127.0.0.1:8000/generate-comic/json `
  -H "Content-Type: application/json" `
  -d "{\"story_prompt\":\"A brave fox exploring an enchanted forest\",\"character_name\":\"Milo\",\"setting\":\"Enchanted forest\",\"tone\":\"light-hearted\",\"art_style\":\"comic book\"}"
```

### Test image generation

```powershell
curl -X POST http://127.0.0.1:8000/test-image `
  -F "prompt=A brave fox in an enchanted forest, comic book style"
```

## 6. Automated tests

The test suite is intentionally independent of paid AI services.

```powershell
$env:COMICCRAFT_MOCK_AI="true"
$env:IMAGE_BACKEND="mock"
pytest -q
```

Expected result:

```text
3 passed
```

The mock mode creates placeholder panel images and a real PDF, so the complete routing and export flow can be tested without API keys.

## 7. Project structure

```text
ComicCraft/
├── app/
│   ├── __init__.py
│   ├── config.py
│   ├── main.py
│   ├── routes.py
│   ├── schemas.py
│   └── services/
│       ├── __init__.py
│       ├── comic_service.py
│       ├── exporters.py
│       ├── gemini.py
│       ├── image_generator.py
│       └── layout_builder.py
├── templates/
│   ├── index.html
│   ├── comic_preview.html
│   └── export_success.html
├── static/
│   ├── css/style.css
│   └── js/app.js
├── outputs/
│   ├── panels/.gitkeep
│   └── exports/.gitkeep
├── tests/test_app.py
├── .env.example
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── run.py
└── README.md
```

## 8. Common problems

### Gemini authentication error

Check:

```text
GEMINI_API_KEY=...
```

and restart the server after changing `.env`.

### Hugging Face authentication/provider error

Check that the token has inference permissions and that the selected model has an available inference provider.

### PDF opens but images are missing

Keep the generated `outputs/` directory. The PDF embeds the image files when it is created; do not delete the output files while testing.

### Slow image generation

Use the Hugging Face backend for cloud inference. Local Diffusers requires suitable hardware and downloads the model.

## 9. Production notes

For production, add authentication, rate limiting, persistent storage, background jobs/queues for long image generation, object storage for generated images, request logging, and cleanup policies for old files.

## Source alignment

The supplied project document describes a three-part architecture (frontend, FastAPI backend, AI services), a five-panel Gemini outline, Gemini-based story expansion, Stable Diffusion image generation, layout construction, PDF export, and the `/generate`, `/generate-comic/json`, `/export-success`, and `/test-image` workflow. This implementation turns those requirements into a complete maintainable project rather than reproducing screenshot snippets.
