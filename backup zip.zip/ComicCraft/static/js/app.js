document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("comicForm");
    const button = document.getElementById("generateButton");

    if (!form || !button) {
        return;
    }

    form.addEventListener("submit", () => {
        button.disabled = true;
        button.textContent = "✨ Generating Comic...";

        button.style.opacity = "0.7";
        button.style.cursor = "not-allowed";
    });
});