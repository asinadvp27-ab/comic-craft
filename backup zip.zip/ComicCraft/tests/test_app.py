from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_home():
    response = client.get("/")

    assert response.status_code == 200
    assert "ComicCraft" in response.text


def test_json_generation():
    response = client.post(
        "/generate-comic/json",
        json={
            "story_prompt": "A fox discovers a magical door.",
            "character_name": "Luna",
            "setting": "Enchanted forest",
            "tone": "Adventurous",
            "art_style": "Colorful comic",
        },
    )

    assert response.status_code == 200

    data = response.json()

    assert len(data["panels"]) == 5
    assert data["pdf_url"].endswith("_comic.pdf")