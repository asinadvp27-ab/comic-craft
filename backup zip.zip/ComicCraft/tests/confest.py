import os

os.environ["COMICCRAFT_MOCK_AI"] = "true"
os.environ["IMAGE_BACKEND"] = "mock"